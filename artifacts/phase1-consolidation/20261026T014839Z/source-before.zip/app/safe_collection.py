"""Explicit, non-navigating recovery checks and bounded search-only capture.

Heartbeat/check never clear a latch. Release is a separate authenticated operator
action. Stage 2 never starts or advances automatically.
"""
import json
import re
import secrets
from datetime import datetime,timezone,timedelta
from urllib.parse import urlsplit,parse_qs
from fastapi import HTTPException

FRESH_SECONDS=15
CHECK_SAMPLES=2
MAX_STAGE1_RESULTS=10
MAX_STAGE2_QUERIES=5
MAX_STAGE2_NEW=30
MAX_RUNTIME_SECONDS=180


def now():return datetime.now(timezone.utc).isoformat()
def encoded(value):return json.dumps(value,sort_keys=True,ensure_ascii=False)
def state(con,key):
    row=con.execute('SELECT value_json FROM system_state WHERE key=?',(key,)).fetchone()
    return json.loads(row[0]) if row else {}
def put(con,key,value):
    con.execute('INSERT INTO system_state(key,value_json,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_at=excluded.updated_at',(key,encoded(value),now()))


def migrate(con):
    con.execute('''CREATE TABLE IF NOT EXISTS safe_recovery_checks (
      id TEXT PRIMARY KEY,status TEXT NOT NULL,created_at TEXT NOT NULL,validated_at TEXT,
      extension_id TEXT NOT NULL,build_id TEXT NOT NULL,incident_json TEXT NOT NULL,
      samples_json TEXT NOT NULL DEFAULT '[]',evidence_json TEXT NOT NULL,release_json TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS safe_collection_batches (
      id TEXT PRIMARY KEY,stage INTEGER NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,
      validation_id TEXT NOT NULL REFERENCES safe_recovery_checks(id),queries_json TEXT NOT NULL,
      query_index INTEGER NOT NULL DEFAULT 0,command_id INTEGER,new_videos INTEGER NOT NULL DEFAULT 0,
      seen INTEGER NOT NULL DEFAULT 0,duplicates INTEGER NOT NULL DEFAULT 0,snapshots INTEGER NOT NULL DEFAULT 0,
      stop_reason TEXT,completed_at TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS safe_stage2_authorizations (
      validation_id TEXT PRIMARY KEY,fresh_check_id TEXT NOT NULL,queries_json TEXT NOT NULL,authorized_at TEXT NOT NULL)''')
    con.execute('''CREATE TABLE IF NOT EXISTS safe_query_metrics (
      command_id INTEGER PRIMARY KEY,batch_id TEXT NOT NULL,query TEXT NOT NULL,status TEXT NOT NULL,
      results INTEGER NOT NULL,new_videos INTEGER NOT NULL,duplicates INTEGER NOT NULL,blocked INTEGER NOT NULL,
      invalid INTEGER NOT NULL,unique_creators INTEGER NOT NULL,category_matches INTEGER NOT NULL,
      observed_at TEXT NOT NULL,snapshots INTEGER NOT NULL)''')
    con.execute('''CREATE TABLE IF NOT EXISTS safe_stage2_resumptions (
      batch_id TEXT PRIMARY KEY,fresh_check_id TEXT NOT NULL,resumed_at TEXT NOT NULL,
      prior_elapsed_seconds REAL NOT NULL,original_json TEXT NOT NULL,command_id INTEGER)''')
    con.execute('''CREATE TABLE IF NOT EXISTS safe_search_diagnostics (
      command_id INTEGER PRIMARY KEY,diagnostics_json TEXT NOT NULL,recorded_at TEXT NOT NULL)''')


def healthy_route(url):
    try:
        u=urlsplit(url)
        return u.scheme=='https' and u.netloc=='www.tiktok.com' and (u.path=='/' or u.path.rstrip('/')=='/search' and bool(parse_qs(u.query).get('q',[''])[0].strip()))
    except ValueError:return False


def health(bridge,extension_id,build_id):
    from .browser_safety import authenticated_account_evidence
    try:age=(datetime.now(timezone.utc)-datetime.fromisoformat(bridge['last_seen'].replace('Z','+00:00'))).total_seconds()
    except (KeyError,ValueError,TypeError):age=None
    fresh=age is not None and 0<=age<FRESH_SECONDS
    page=bridge.get('current_page_status','unknown');session=bridge.get('tiktok_session_status','unconfirmed')
    evidence={'mode':'SAFE_RECOVERY_CHECK','companion_connected':fresh and bridge.get('extension_id')==extension_id,
        'heartbeat_fresh':fresh,'document_ready':bridge.get('page_ready_state')=='complete',
        'current_url':bridge.get('current_url',''),'tab_id':bridge.get('tab_id'),'page_status':page,
        'challenge_indicators':page=='challenge','http_403_indicators':page=='http_403',
        'account_signals':bridge.get('session_evidence',[]),'session':session,'heartbeat_at':bridge.get('last_seen'),
        'build_matches':bool(build_id) and bridge.get('build_id')==build_id}
    status='BLOCKED' if fresh and page=='http_403' else 'CHALLENGE' if fresh and page=='challenge' else 'UNKNOWN'
    if all((evidence['companion_connected'],evidence['heartbeat_fresh'],evidence['document_ready'],
            evidence['build_matches'],healthy_route(evidence['current_url']),bridge.get('tab_id') is not None,
            page=='healthy',session=='confirmed',authenticated_account_evidence(bridge))):status='HEALTHY'
    return {'status':status,**evidence}


def request_check(con,extension_id):
    migrate(con)
    if con.execute("SELECT 1 FROM bridge_commands WHERE status IN ('PENDING','DISPATCHED')").fetchone():raise HTTPException(409,'Active content command; check refused')
    bridge=state(con,'tiktok_bridge');ident=secrets.token_hex(16);build=bridge.get('build_id','')
    evidence=health(bridge,extension_id,build);status='PENDING' if evidence['status']=='HEALTHY' else evidence['status']
    con.execute('INSERT INTO safe_recovery_checks(id,status,created_at,extension_id,build_id,incident_json,evidence_json) VALUES (?,?,?,?,?,?,?)',
        (ident,status,now(),extension_id,build,encoded(state(con,'browser_security_stop')),encoded(evidence)))
    return {'id':ident,'status':status,'evidence':evidence,'security_stop_released':False}


def observe_heartbeat(con,bridge):
    """Consume two fresh real heartbeat samples; no navigation or release side effect."""
    migrate(con)
    block=None
    for row in con.execute("SELECT * FROM safe_recovery_checks WHERE status='PENDING'").fetchall():
        evidence=health(bridge,row['extension_id'],row['build_id']);samples=json.loads(row['samples_json'])
        status=evidence['status']
        if state(con,'browser_security_stop')!=json.loads(row['incident_json']):status='UNKNOWN';evidence['reason']='INCIDENT_CHANGED'
        if not bridge.get('last_seen') or bridge['last_seen']<=row['created_at']:continue
        if (datetime.now(timezone.utc)-datetime.fromisoformat(row['created_at'])).total_seconds()>30:status='UNKNOWN';evidence['reason']='CHECK_EXPIRED'
        if status=='HEALTHY':
            if samples and any(samples[-1].get(k)!=evidence.get(k) for k in ('current_url','tab_id')):status='UNKNOWN';evidence['reason']='TAB_CHANGED'
            else:
                if not samples or samples[-1]['heartbeat_at']!=evidence['heartbeat_at']:samples.append(evidence)
                status='HEALTHY' if len(samples)>=CHECK_SAMPLES else 'PENDING'
        if status in ('BLOCKED','CHALLENGE'):block='SAFE_RECOVERY_CHECK '+status+': '+evidence['current_url']
        con.execute('UPDATE safe_recovery_checks SET status=?,validated_at=?,samples_json=?,evidence_json=? WHERE id=?',
            (status,now() if status=='HEALTHY' else None,encoded(samples),encoded(evidence),row['id']))
    return block


def release(con,ident,extension_id):
    row=con.execute('SELECT * FROM safe_recovery_checks WHERE id=?',(ident,)).fetchone()
    if not row or row['status']!='HEALTHY' or row['release_json']:raise HTTPException(409,'Fresh HEALTHY manual check required; release is not automatic')
    incident=state(con,'browser_security_stop');bridge=state(con,'tiktok_bridge')
    if incident!=json.loads(row['incident_json']) or not re.search(r'403|access.denied',incident.get('reason',''),re.I):raise HTTPException(409,'Incident changed or is not a reviewed historical access block')
    current=health(bridge,extension_id,row['build_id']);previous=json.loads(row['evidence_json'])
    if (current['status']!='HEALTHY' or len(json.loads(row['samples_json']))<CHECK_SAMPLES or
        any(current.get(k)!=previous.get(k) for k in ('current_url','tab_id')) or
        (datetime.now(timezone.utc)-datetime.fromisoformat(row['validated_at'])).total_seconds()>=FRESH_SECONDS):raise HTTPException(409,'Validation expired or current page changed')
    if con.execute("SELECT 1 FROM bridge_commands WHERE status IN ('PENDING','DISPATCHED')").fetchone():raise HTTPException(409,'Active content command')
    record={'released_at':now(),'validated_url':current['current_url'],'validation_evidence':json.loads(row['samples_json']),
        'previous_incident':incident,'validation_id':ident,'release_type':'EXPLICIT_OPERATOR_ACTION'}
    history=state(con,'browser_security_history').get('items',[])
    put(con,'browser_security_history',{'items':[*history,{**incident,**record}]})
    put(con,'browser_security_clearance',incident);put(con,'browser_security_stop',{})
    put(con,'safe_collection_guard',{'enabled':True,'validation_id':ident})
    con.execute('UPDATE safe_recovery_checks SET release_json=? WHERE id=?',(encoded(record),ident))
    return record


def start(con,ident,queries,stage=1):
    migrate(con)
    if stage not in (1,2) or not queries or len(queries)>(1 if stage==1 else MAX_STAGE2_QUERIES) or len(set(queries))!=len(queries):raise HTTPException(422,'Bounded unique query list required')
    if stage==2 and not con.execute("SELECT 1 FROM safe_collection_batches WHERE stage=1 AND status='SUCCEEDED' AND validation_id=?",(ident,)).fetchone():raise HTTPException(409,'Stage 1 must pass for this validation first')
    if stage==2 and con.execute('SELECT 1 FROM safe_collection_batches WHERE stage=2 AND validation_id=?',(ident,)).fetchone():raise HTTPException(409,'Stage 2 already attempted for this validation; no retry')
    if stage==1 and con.execute('SELECT 1 FROM safe_collection_batches WHERE stage=1 AND validation_id=?',(ident,)).fetchone():raise HTTPException(409,'Stage 1 already attempted for this validation; no retry')
    check=con.execute('SELECT * FROM safe_recovery_checks WHERE id=?',(ident,)).fetchone()
    if not check or not check['release_json']:raise HTTPException(409,'Explicit release required')
    stage2auth=con.execute('SELECT * FROM safe_stage2_authorizations WHERE validation_id=?',(ident,)).fetchone() if stage==2 else None
    if json.loads(check['release_json']).get('authorization_type')=='SEARCH_ONLY_STAGE1' and stage!=1 and not stage2auth:raise HTTPException(409,'This authorization is Stage 1 search-only')
    if stage2auth and queries!=json.loads(stage2auth['queries_json']):raise HTTPException(409,'Queries differ from explicit Stage 2 pack authorization')
    guard=state(con,'safe_collection_guard')
    if not guard.get('enabled') or guard.get('validation_id')!=ident:raise HTTPException(409,'Matching safe collection guard required')
    for query in queries:
        if not isinstance(query,str) or not query.strip() or len(query)>200:raise HTTPException(422,'Invalid query')
        if not stage2auth and not con.execute('SELECT 1 FROM search_observations WHERE search_query=?',(query,)).fetchone():raise HTTPException(409,'Only previously observed queries are allowed')
    batch=secrets.token_hex(16)
    con.execute("INSERT INTO safe_collection_batches(id,stage,status,created_at,validation_id,queries_json) VALUES (?,?,'READY',?,?,?)",(batch,stage,now(),ident,encoded(queries)))
    return advance(con,batch)


def advance(con,batch):
    row=con.execute('SELECT * FROM safe_collection_batches WHERE id=?',(batch,)).fetchone()
    if not row or row['status'] not in ('READY','PAUSED'):raise HTTPException(409,'Batch stopped; no automatic continuation')
    bridge=state(con,'tiktok_bridge');check=collection_check(con,row)
    if state(con,'browser_security_stop').get('reason'):raise HTTPException(409,'SECURITY_BLOCK: zero retries')
    if state(con,'target_security_pending').get('items'):raise HTTPException(409,'Target HTTP 403: passive healthy home/search required')
    if health(bridge,check['extension_id'],check['build_id'])['status']!='HEALTHY':raise HTTPException(409,'HEALTHY current page required')
    if bridge.get('safe_collection_version')!='v1':raise HTTPException(409,'Bounded capture Companion build required')
    remaining=MAX_RUNTIME_SECONDS-runtime_used(con,row)
    if remaining<=0:raise HTTPException(409,'Bounded runtime reached')
    if row['stage']==2 and remaining<35:raise HTTPException(409,'Insufficient runtime for another bounded viewport')
    queries=json.loads(row['queries_json'])
    if row['query_index']>=len(queries) or row['new_videos']>=(MAX_STAGE1_RESULTS if row['stage']==1 else MAX_STAGE2_NEW):raise HTTPException(409,'Hard limit reached')
    from .dev_control import active_operations
    if any(active_operations(con).values()):raise HTTPException(409,'Another operation owns the tab')
    cap=min(MAX_STAGE1_RESULTS,(MAX_STAGE1_RESULTS if row['stage']==1 else MAX_STAGE2_NEW)-row['new_videos'])
    options={'safe_collection_id':batch,'max_results':cap,'navigate_search':True,'max_scrolls':0,'max_runtime':60,'expected_tab_id':bridge['tab_id'],'validated_url':bridge['current_url']}
    if row['stage']==2:
        options['deadline_at']=(datetime.now(timezone.utc)+timedelta(seconds=remaining)).isoformat()
        options['strict_health']=True
    cur=con.execute("INSERT INTO bridge_commands(created_at,updated_at,type,query,status,extension_id,options_json) VALUES (?,?,'READ_SEARCH_RESULTS',?,'PENDING',?,?)",(now(),now(),queries[row['query_index']],check['extension_id'],encoded(options)))
    con.execute("UPDATE safe_collection_batches SET status='PENDING',command_id=?,query_index=query_index+1 WHERE id=?",(cur.lastrowid,batch))
    return {'id':batch,'command_id':cur.lastrowid,'stage':row['stage'],'max_results':cap,'status':'PENDING'}


def command_allowed(con,row):
    if state(con,'target_security_pending').get('items'):return False
    if json.loads(row['options_json']).get('selective_run_id'):
        from .selective_enrichment import command_allowed as selective_allowed
        return selective_allowed(con,row)
    guard=state(con,'safe_collection_guard')
    if not guard.get('enabled'):return True
    if row['type']!='READ_SEARCH_RESULTS':return False
    batch=con.execute("SELECT * FROM safe_collection_batches WHERE command_id=? AND status='PENDING'",(row['id'],)).fetchone()
    if not batch or guard.get('validation_id')!=batch['validation_id']:return False
    check=collection_check(con,batch)
    bridge=state(con,'tiktok_bridge')
    return bool(check and bridge.get('safe_collection_version')=='v1' and
        health(bridge,check['extension_id'],check['build_id'])['status']=='HEALTHY' and
        runtime_used(con,batch)<MAX_RUNTIME_SECONDS)


def runtime_used(con,batch):
    clock=datetime.fromisoformat(batch['completed_at']) if batch['status'] in ('SUCCEEDED','FAILED') and batch['completed_at'] else datetime.now(timezone.utc)
    resume=con.execute('SELECT * FROM safe_stage2_resumptions WHERE batch_id=?',(batch['id'],)).fetchone()
    if resume:return resume['prior_elapsed_seconds']+(clock-datetime.fromisoformat(resume['resumed_at'])).total_seconds()
    return (clock-datetime.fromisoformat(batch['created_at'])).total_seconds()


def collection_check(con,batch):
    resume=con.execute('SELECT fresh_check_id FROM safe_stage2_resumptions WHERE batch_id=?',(batch['id'],)).fetchone()
    if resume:return con.execute('SELECT * FROM safe_recovery_checks WHERE id=?',(resume['fresh_check_id'],)).fetchone()
    auth=con.execute('SELECT fresh_check_id FROM safe_stage2_authorizations WHERE validation_id=?',(batch['validation_id'],)).fetchone() if batch['stage']==2 else None
    return con.execute('SELECT * FROM safe_recovery_checks WHERE id=?',(auth['fresh_check_id'] if auth else batch['validation_id'],)).fetchone()


def authorize_healthy_stage1(con,ident,extension_id):
    """Explicit search-only authorization after a new passive check; clears no latch."""
    row=con.execute('SELECT * FROM safe_recovery_checks WHERE id=?',(ident,)).fetchone()
    if not row or row['status']!='HEALTHY' or row['release_json']:raise HTTPException(409,'New HEALTHY passive check required')
    if state(con,'browser_security_stop').get('reason') or state(con,'target_security_pending').get('items'):raise HTTPException(409,'Security is blocked or pending')
    bridge=state(con,'tiktok_bridge');current=health(bridge,extension_id,row['build_id'])
    previous=json.loads(row['evidence_json'])
    if current['status']!='HEALTHY' or len(json.loads(row['samples_json']))<CHECK_SAMPLES or any(current.get(k)!=previous.get(k) for k in ('current_url','tab_id')) or (datetime.now(timezone.utc)-datetime.fromisoformat(row['validated_at'])).total_seconds()>=FRESH_SECONDS:raise HTTPException(409,'Fresh matching healthy home/search required')
    if con.execute("SELECT 1 FROM bridge_commands WHERE status IN ('PENDING','DISPATCHED')").fetchone():raise HTTPException(409,'Active content command')
    record={'authorization_type':'SEARCH_ONLY_STAGE1','authorized_at':now(),'validated_url':current['current_url'],'validation_evidence':json.loads(row['samples_json'])}
    con.execute('UPDATE safe_recovery_checks SET release_json=? WHERE id=?',(encoded(record),ident))
    put(con,'safe_collection_guard',{'enabled':True,'validation_id':ident})
    return record


def authorize_stage2(con,ident,fresh,queries,extension_id):
    migrate(con)
    passed=con.execute("SELECT 1 FROM safe_collection_batches WHERE stage=1 AND status='SUCCEEDED' AND validation_id=?",(ident,)).fetchone()
    if not passed:raise HTTPException(409,'Stage 1 success required')
    if con.execute('SELECT 1 FROM safe_collection_batches WHERE stage=2 AND validation_id=?',(ident,)).fetchone():raise HTTPException(409,'Stage 2 already attempted; no retry')
    if con.execute('SELECT 1 FROM safe_stage2_authorizations WHERE validation_id=?',(ident,)).fetchone():raise HTTPException(409,'Stage 2 authorization already exists')
    from .category_intelligence import config
    pack={q[0] for q in config('discovery_intelligence')['queries'] if q[1]=='home'}
    if not queries or len(queries)>MAX_STAGE2_QUERIES or len(set(queries))!=len(queries) or not set(queries)<=pack:raise HTTPException(422,'At most five unique queries from current Casa pack required')
    # Reuse the existing two-sample, no-latch, no-active-command authorization gate.
    authorize_healthy_stage1(con,fresh,extension_id)
    old=con.execute('SELECT * FROM safe_recovery_checks WHERE id=?',(ident,)).fetchone()
    check=con.execute('SELECT * FROM safe_recovery_checks WHERE id=?',(fresh,)).fetchone()
    if old['extension_id']!=extension_id:raise HTTPException(409,'Passed Stage 1 Companion identity changed')
    con.execute('INSERT INTO safe_stage2_authorizations VALUES (?,?,?,?)',(ident,fresh,encoded(queries),now()))
    put(con,'safe_collection_guard',{'enabled':True,'validation_id':ident})
    return {'validation_id':ident,'queries':queries,'max_queries':MAX_STAGE2_QUERIES,'max_new_videos':MAX_STAGE2_NEW,'max_runtime_seconds':MAX_RUNTIME_SECONDS}


def resume_stage2(con,batch_id,fresh,extension_id):
    """One explicit resume of a zero-observation transient failure; same batch."""
    migrate(con)
    existing=con.execute('SELECT * FROM safe_stage2_resumptions WHERE batch_id=?',(batch_id,)).fetchone()
    if existing:
        return {'id':batch_id,'command_id':existing['command_id'],'stage':2,'reused':True}
    job=con.execute('SELECT * FROM safe_collection_batches WHERE id=?',(batch_id,)).fetchone()
    if not job or job['stage']!=2 or job['status']!='FAILED':raise HTTPException(409,'Interrupted Stage 2 batch required')
    command=con.execute('SELECT * FROM bridge_commands WHERE id=?',(job['command_id'],)).fetchone()
    if not command or command['status']!='FAILED' or command['extension_id']!=extension_id:raise HTTPException(409,'Matching failed command required')
    if re.search(r'403|access.denied|challenge|captcha|verify.*human|LOGGED_OUT|UNEXPECTED_HOST|SEARCH_ROUTE_INVALID',command['detail'],re.I):raise HTTPException(409,'Hard-stop commands cannot resume')
    if not ('Stage 2 session/page not healthy' in command['detail'] or 'SESSION_NOT_STABLE' in command['detail']):raise HTTPException(409,'Only transient stability failure may resume; no hard-stop retry')
    if con.execute('SELECT 1 FROM search_observations WHERE capture_id=?',(f"command:{command['id']}",)).fetchone():raise HTTPException(409,'Interrupted query already persisted; resume refused')
    queries=json.loads(job['queries_json']);index=job['query_index']-1
    if index<0 or queries[index]!=command['query']:raise HTTPException(409,'Checkpoint query mismatch')
    if con.execute("SELECT 1 FROM safe_query_metrics WHERE batch_id=? AND query=? AND status='SUCCEEDED'",(batch_id,command['query'])).fetchone():raise HTTPException(409,'Query already completed')
    prior_elapsed=max(0,(datetime.fromisoformat(job['completed_at'])-datetime.fromisoformat(job['created_at'])).total_seconds())
    if prior_elapsed>=MAX_RUNTIME_SECONDS-35 or job['new_videos']>=MAX_STAGE2_NEW:raise HTTPException(409,'Original budget exhausted')
    # Fresh two-sample evidence; this does not clear security or replace Stage 1.
    authorize_healthy_stage1(con,fresh,extension_id)
    con.execute('INSERT INTO safe_stage2_resumptions VALUES (?,?,?,?,?,NULL)',(batch_id,fresh,now(),prior_elapsed,encoded(dict(job))))
    put(con,'safe_collection_guard',{'enabled':True,'validation_id':job['validation_id']})
    con.execute("UPDATE safe_collection_batches SET status='PAUSED',query_index=?,stop_reason='EXPLICIT_TRANSIENT_RESUME',completed_at=NULL WHERE id=?",(index,batch_id))
    result=advance(con,batch_id)
    con.execute('UPDATE safe_stage2_resumptions SET command_id=? WHERE batch_id=?',(result['command_id'],batch_id))
    return {**result,'reused':False,'prior_elapsed_seconds':prior_elapsed}


def finish(con,row,status,capture,inserted=0,updated=0):
    options=json.loads(row['options_json']);batch=options.get('safe_collection_id')
    if not batch:return
    job=con.execute('SELECT * FROM safe_collection_batches WHERE id=? AND command_id=?',(batch,row['id'])).fetchone()
    if not job:raise ValueError('Safe collection ownership mismatch')
    seen=len(capture['results']) if capture else 0
    snaps=con.execute("SELECT count(*) FROM trend_snapshot_sources p JOIN search_observations o ON p.source_key='search_observations:'||o.id WHERE o.capture_id=?",(f"command:{row['id']}",)).fetchone()[0]
    final='FAILED' if status!='SUCCEEDED' else 'SUCCEEDED' if job['stage']==1 or job['query_index']>=len(json.loads(job['queries_json'])) or job['new_videos']+inserted>=MAX_STAGE2_NEW else 'PAUSED'
    reason='COMMAND_FAILED_NO_RETRY' if status!='SUCCEEDED' else 'CAPTURE_COMPLETED_STOP' if job['stage']==1 else 'MAX_NEW_VIDEOS' if job['new_videos']+inserted>=MAX_STAGE2_NEW else 'MAX_QUERIES' if final=='SUCCEEDED' else 'OPERATOR_ADVANCE_REQUIRED'
    con.execute('UPDATE safe_collection_batches SET status=?,new_videos=new_videos+?,seen=seen+?,duplicates=duplicates+?,snapshots=?,stop_reason=?,completed_at=? WHERE id=?',
        (final,inserted,seen,updated,job['snapshots']+snaps,reason,now(),batch))
    if job['stage']==2:
        from .target_safety import blocked
        observations=[dict(r) for r in con.execute('SELECT * FROM search_observations WHERE capture_id=?',(f"command:{row['id']}",))]
        fields=[json.loads(r['fields_json']) for r in observations]
        creators={v['creator_username'] for v in fields if v.get('creator_username')}
        blocked_count=sum(blocked(con,v.get('video_url','')) for v in fields)
        matches=sum(bool(con.execute("SELECT 1 FROM video_category_classifications WHERE id=(SELECT max(id) FROM video_category_classifications WHERE video_id=?) AND primary_category='home'",(r['video_id'],)).fetchone()) for r in observations)
        observed=max((r['observed_at'] for r in observations),default=now())
        con.execute('INSERT INTO safe_query_metrics VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',(row['id'],batch,row['query'],status,seen,inserted,updated,blocked_count,(capture or {}).get('invalid_results',0),len(creators),matches,observed,snaps))


def post_capture(con,command_id):
    from .category_intelligence import classify_library
    from .intelligence_core import observation,work_payload
    from .intelligence_jobs import enqueue
    ids=[r[0] for r in con.execute('SELECT video_id FROM search_observations WHERE capture_id=?',(f'command:{command_id}',))]
    if ids:classify_library(con,ids)
    batch=con.execute('SELECT stage FROM safe_collection_batches WHERE command_id=?',(command_id,)).fetchone()
    if batch and batch['stage']==2:return  # Search-only Stage 2 never schedules resolver/enrichment work.
    for vid in ids:enqueue(con,'identity',vid,work_payload(con,observation(con,vid)))


def summary(con):
    migrate(con);bridge=state(con,'tiktok_bridge')
    check=con.execute('SELECT * FROM safe_recovery_checks ORDER BY created_at DESC LIMIT 1').fetchone()
    batch=con.execute('SELECT * FROM safe_collection_batches ORDER BY created_at DESC LIMIT 1').fetchone()
    healthy=con.execute("SELECT * FROM safe_recovery_checks WHERE status='HEALTHY' ORDER BY validated_at DESC LIMIT 1").fetchone()
    fresh=health(bridge,bridge.get('extension_id',''),bridge.get('build_id',''))['companion_connected']
    return {'companion':fresh,
        'session':bridge.get('tiktok_session_status','unconfirmed') if fresh else 'unconfirmed','page':bridge.get('current_page_status','unknown') if fresh else 'unknown',
        'security_stop':state(con,'browser_security_stop'),'last_safe_validation':dict(healthy) if healthy else None,
        'last_check':dict(check) if check else None,'last_collection':dict(batch) if batch else None,
        'new_videos':batch['new_videos'] if batch else 0,'last_stop_reason':state(con,'browser_security_stop').get('reason') or (batch['stop_reason'] if batch else None)}
