"""Explicit session UX using the existing authenticated Companion command queue."""
import re
from fastapi import APIRouter,Request,HTTPException
from . import db
from .dev_control import settings,DevCommand,create
from .intelligence_api import local_write

router=APIRouter()

@router.get('/api/session/state')
def session_state():
    from .main import live_bridge
    from .companion_contract import contract
    with db.connect() as con:
        renew=con.execute("SELECT id,status,detail,updated_at FROM dev_commands WHERE type='DEV_RENEW_TIKTOK_SESSION' ORDER BY created_at DESC LIMIT 1").fetchone() if con.execute("SELECT 1 FROM sqlite_master WHERE name='dev_commands'").fetchone() else None
        check=con.execute('SELECT id,status,validated_at FROM safe_recovery_checks ORDER BY created_at DESC LIMIT 1').fetchone()
    return {**contract(),'bridge':live_bridge(),'security_stop':db.get_state('browser_security_stop',{}),
            'renewal':dict(renew) if renew else None,'check':dict(check) if check else None}

@router.post('/api/tiktok/renew')
def renew(request:Request):
    local_write(request)
    config=settings()
    from .companion_contract import compatibility
    bridge=db.get_state('tiktok_bridge',{})
    if not compatibility(bridge)['companion_compatible']:raise HTTPException(409,'COMPANION DESATUALIZADO: reload required before session renewal')
    result=create(DevCommand(type='DEV_RENEW_TIKTOK_SESSION',expected_build=bridge['build_id']),config)
    return {**result,'ok':True,'message':'Renovacao solicitada no Chrome existente; security stop preservado; login manual se necessario.'}

@router.post('/api/tiktok/verify')
def verify(request:Request):
    local_write(request)
    config=settings()
    from .safe_collection import request_check
    with db.connect() as con:
        con.execute('BEGIN IMMEDIATE')
        return request_check(con,config['extension_id'])
