from app import db
from test_dev_control import dev_api


def test_small_session_endpoint_is_read_only_and_exposes_queue_failure(dev_api):
    db.set_state('browser_security_stop',{'reason':'HTTP 403 historical'})
    code,_=dev_api('/api/bridge/heartbeat',{'extension_version':'0.1.6','companion_version':'0.1.6','api_version':'1','build_id':'1'*16,'command_api_status':404,'command_api_error':'API error: /api/dev/commands/next [404]'})
    assert code==200
    with db.connect() as c:
        tables=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        before={name:c.execute('SELECT count(*) FROM "'+name+'"').fetchone()[0] for name in tables}
    code,d=dev_api('/api/session/state')
    assert code==200 and d['bridge']['command_api_status']==404
    assert d['security_stop']['reason']=='HTTP 403 historical'
    assert d['renewal'] is None and d['check'] is None
    with db.connect() as c:
        assert tables==[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        assert before=={name:c.execute('SELECT count(*) FROM "'+name+'"').fetchone()[0] for name in before}


def test_heartbeat_recovery_is_visible_without_check_or_navigation(dev_api):
    for status in (404,200):
        dev_api('/api/bridge/heartbeat',{'extension_version':'0.1.6','command_api_status':status})
        assert dev_api('/api/session/state')[1]['bridge']['command_api_status']==status
    with db.connect() as c:
        assert c.execute('SELECT count(*) FROM bridge_commands').fetchone()[0]==0
        assert c.execute('SELECT count(*) FROM safe_recovery_checks').fetchone()[0]==0
